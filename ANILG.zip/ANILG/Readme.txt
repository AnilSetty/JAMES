java -jar vijay.jar 1 >(Filename) --- Credit
java -jar vijay.jar 2 >(Filename) --- Debit







java -jar vijay.jar 2 > FRD15_DEBIT_JUNE2018.txt



java -jar vijay.jar 1 > TEST.txt 
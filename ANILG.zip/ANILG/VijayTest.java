package com;

import java.util.*;
import java.sql.*;
import java.io.*;

public class VijayTest
{
    private static Properties properties;
    static String query;
    static String dburl;
    static String dbuser;
    static String dbpassword;
    static String header;
    static String footer;
    
    static {
        VijayTest.properties = null;
    }
    
    public static void main(final String[] args) throws Exception {
        loadProperties(args[0]);
        final Connection con = getConnection();
        final Statement st = con.createStatement();
        final ResultSet rs = st.executeQuery(VijayTest.query);
        final ResultSetMetaData md = rs.getMetaData();
        final int colCnt = md.getColumnCount();
        final StringBuffer sb = new StringBuffer();
        sb.append(VijayTest.header);
        sb.append(System.getProperty("line.separator"));
        int recordsCnt = 0;
        while (rs.next()) {
            ++recordsCnt;
            for (int i = 1; i <= colCnt; ++i) {
                sb.append(rs.getString(i));
            }
            sb.append(System.getProperty("line.separator"));
        }
        sb.append(getFooter(VijayTest.footer, recordsCnt));
        System.out.println(sb.toString());
    }
    
    public static Connection getConnection() {
        Connection l_Connection = null;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            l_Connection = DriverManager.getConnection(VijayTest.dburl, VijayTest.dbuser, VijayTest.dbpassword);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return l_Connection;
    }
    
    public static String getFooter(final String footer, final int i) {
        final String s = new StringBuilder(String.valueOf(i)).toString();
        final int len = s.length();
        final String newFooter = String.valueOf(footer.substring(0, footer.length() - len)) + s;
        return newFooter;
    }
    
    public static void loadProperties(final String a) {
        try {
            final File file = new File("config" + a + ".properties");
            final FileInputStream fileInput = new FileInputStream(file);
            (VijayTest.properties = new Properties()).load(fileInput);
            VijayTest.query = VijayTest.properties.getProperty("query");
            VijayTest.dburl = VijayTest.properties.getProperty("dburl");
            VijayTest.dbuser = VijayTest.properties.getProperty("dbuser");
            VijayTest.dbpassword = VijayTest.properties.getProperty("dbpassword");
            VijayTest.header = VijayTest.properties.getProperty("header");
            VijayTest.footer = VijayTest.properties.getProperty("footer");
        }
        catch (IOException io) {
            io.printStackTrace();
        }
    }
}
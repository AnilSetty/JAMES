function viewsipdet(){
	document.frm.action='view_sip.jsp';
	document.frm.method ='post';
	document.frm.submit();
}


function hidepop(obj,lyr)
{
	var x = document.getElementById(lyr);
	x.style.display = "none";
}

function showpop(obj,lyr,cont,conthead)
{
	var coors = findPos(obj)	
	var x = document.getElementById(lyr);
	var cont1 = cont;
	var conthead1 = conthead;
	
	x.style.display = "block";
	x.style.top = coors[1] + -10 + 'px';	
	x.style.left = coors[0] + 18 + 'px';	
	
	document.getElementById('rollcontent').innerHTML=cont1;
	document.getElementById('contheader').innerHTML=conthead1;
}

function findPos(obj) {
	var curleft = curtop = 0;
	if (obj.offsetParent) {
		do {
			curleft += obj.offsetLeft;
			curtop += obj.offsetTop;
		} while (obj = obj.offsetParent);
	}
	//alert(curleft)
	return [curleft,curtop];
}

function openwindow(url, width, height) { 
	
var win;
var windowName;
var params;
windowName = "features";
params = "toolbar=0,";
params += "location=0,";
params += "directories=0,";
params += "status=1,";
params += "menubar=0,";
params += "titlebar=0,";
params += "scrollbars=1,";
params += "resizable=1,";
params += "top=50,";
params += "left=50,";
params += "modal=yes,";
params += "width="+width+",";
//params += "width=120,";
params += "height="+height;
//params += ",fullscreen";

win = window.open(url, windowName, params);  
}

var widths = screen.width
var heights = screen.height

function getWidthHeight()
{
	if(widths > 800)
	{
		customheight = heights-90;		
		return customheight;					
	}
	else
	{
		customheight = 0;
		return customheight;
	}
}

function fncInputNumericValuesOnly()
{
if(!(event.keyCode==48||event.keyCode==49||event.keyCode==50||event.keyCode==51||event.keyCode==52||event.keyCode==53||event.keyCode==54||event.keyCode==55||event.keyCode==56||event.keyCode==57))
{
event.returnValue=false;
}
}

function funInputDecimalValues(){
	if(!(event.keyCode==46||event.keyCode==48||event.keyCode==49||event.keyCode==50||event.keyCode==51||event.keyCode==52||event.keyCode==53||event.keyCode==54||event.keyCode==55||event.keyCode==56||event.keyCode==57))
	{
	event.returnValue=false;
	}
}

//for right click disable
function mouseClickHandle()
{
var value = event.button;
if (value==2 || value==3)
  {
alert('Due to security reasons, Right Click is not allowed');
  }
}
document.onmousedown=mouseClickHandle;


function tncagree(val,sch,amt,val1,actno)
{
	document.getElementById('button').disabled=true;
	document.frm.val.value =val;
	document.frm.valpro.value =sch;
	//alert(document.frm.valpro.value);
	document.frm.textfield.value =amt;
	document.frm.st.value =val1;
	//document.frm.actno.value=actno;

	if(document.frm.terms.checked)
	{
		//alert("purchase");
		document.frm.action="transaction_verification.jsp";
	    document.frm.method="post";
		document.frm.submit();
	}
	else
	{
		alert("Please agree to the terms and conditions");
		document.getElementById('button').disabled=false;
		return (false);
	}
}

function activateme()
{
	document.frm.terms.disabled=false;
	
}

//Purchase first page back and cancel & Purchase secong page cancel
 function runBack(bck)
 {
	 if(bck=='MP'){
	 document.frm.action="mutual_fund_reg_user_fund.jsp";
	 document.frm.method="post";
    document.frm.submit();
	 }
	 else if(bck=='SP'){
		document.frm.action="mutual_select_fund2.jsp";
		document.frm.method="post";
		document.frm.submit();
	 }
	else if(bck=='Cancel'){
		 document.frm.action="mutual_fund_reg_user_fund.jsp";
		 document.frm.method="post";
   		 document.frm.submit();
	 }
	 else if(bck=='Back1'){
	 document.frm.action="mutual_select_fund2.jsp";
	 document.frm.method="post";
       document.frm.submit();
	 }
       else{
       document.frm.action="my_portfolio.jsp";
	 document.frm.method="post";
       document.frm.submit();
       }
 }

 // Back for Purchase first page
 function runSubmit()
 {
	 document.frm.proceedButton.disabled=true;
	 var amt =  parseFloat(document.frm.textfield.value);
	 var min =  parseFloat(document.frm.min_amt.value);
	 var mul = parseFloat(document.frm.mul.value);
	 //alert(amt+"|"+min+"|"+mul);
	 var mo_mul = (amt%mul);
	 if(mo_mul!=0)
	 {
		  alert("Pls Check minimum and multiple Amount ");
		  document.frm.proceedButton.disabled=false;
		  document.frm.textfield.focus();
		  document.frm.textfield.value="";
		  return false;
	 }
	 else if(document.frm.textfield.value=="")
	 {
		alert("Amount not filled");
		document.frm.proceedButton.disabled=false;
		document.frm.textfield.focus();
		return false;
	  }
	 else if((amt>parseFloat(document.frm.bal.value)))
	 {
		  alert("Amount Cannot be greater than Current Balance");
  		  document.frm.proceedButton.disabled=false;
		  document.frm.textfield.focus();
		  document.frm.textfield.value="";
		  return false;
	  }
	  else if((amt<min))
	  {
		  alert("Amount should be at least minimum amount");
		  document.frm.proceedButton.disabled=false;
		  document.frm.textfield.focus();
		  document.frm.textfield.value="";
		  return false;
		  }
	  else if((amt<=parseFloat(document.frm.bal.value)) && (amt>=min))
	  {
//		alert("Here" +amt+"|"+ min +"|"+document.frm.bal.value );
        document.frm.action="m_purchase2.jsp";
		//alert(document.frm.action);
        document.frm.method="post";
	//if(amt>=50000)
	//alert("Customers who invest Rs.50,000 or more in mutual funds need to be CVL KYC compliant. To know about CVL KYC, please refer to FAQs");
       document.frm.submit();
	  }
 }

 // for purchase first page div options
function Div_R()
{
	   if (document.frm.radio[0].checked==true)
				  {
				   document.frm.divradio.value="";
			 	   document.frm.divradio.value = "Y";
				  }	 
			 else{
				 document.frm.divradio.value="";
				 document.frm.divradio.value = "N";
			 }
}

function runBack1(sch,actno)
 {
	 //alert(sch);
	 document.frm.val.value =sch;
 	 document.frm.valpro.value =sch;
	 document.frm.SessionActno.value=actno;
	 document.frm.action="mutual_place_purchase1.jsp";
	 document.frm.method="post";
   	 document.frm.submit();
 }

 function printpage()
{
       document.getElementById("print").style.display="block";
//alert();
       window.print();
	 document.getElementById("print").style.display="none";
	 return false;
}

function sendEmail()
{
	//alert("sending Email");
	return false;	
}



function home()
{
        //document.frm.action="mutual_fund_reg_user_fund.jsp";
		document.frm.action="investeasy_scheme.jsp";
        document.frm.method ="post";
        document.frm.submit();

}

function viewportfolio(){
	document.frm.action='my_portfolio.jsp';
	document.frm.method ='post';
	document.frm.submit();
}

function viewtrr(){
	document.frm.action='investeasy_pb_index.jsp';
	document.frm.method ='post';
	document.frm.submit();
}
//*************************
function viewpurchase1(trn,amc,scm,act,opt) {
		//alert(trn+"|"+amc+"|"+scm+"|"+act+"|"+opt);
		var tot = amc+"|"+scm+"|"+act+"|"+opt;
		if(act=='PUR' && trn=='Y'){
			 document.frm.val.value =tot;
			// document.frm.action="Furthur_mutual_place_purchase1.jsp";investeasy_purchaserequest_1.jsp
			document.frm.action="investeasy_purchaserequest_1.jsp";
			 document.frm.method="post";
   			 document.frm.submit();
		}
		else
			alert("Purchase not allowed");
}

function viewpurchase(trn,amc,scm,act,opt) {
	//	alert(trn+"|"+amc+"|"+scm+"|"+act+"|"+opt);
		var tot = amc+"|"+scm+"|"+act+"|"+opt;
		if(act=='PUR' && trn=='Y'){
			 document.frm.val.value =tot;
			 document.frm.action="mutual_place_purchase1.jsp";
			 document.frm.method="post";
   			 document.frm.submit();
		}
		else
			alert("Purchase not allowed");
}

function viewredeem(trn,amc,scm,act){
		if (act=="Y" && trn=="Y")
		{
			var tot = amc+"|"+scm;
			 document.frm.val.value =tot;
			 document.frm.action="redeem1.jsp";
			 document.frm.method="post";
   			 document.frm.submit();
		}
		else
			alert("Redemption not allowed");
}

function viewswitch(trn,amc,scm,type,act){
		if (act=="Y" && trn=="Y")
		{
			var tot = amc+"|"+scm+"|"+type;
			 document.frm.val.value =tot;
			 document.frm.action="investeasy_redeemrequest_switch_test.jsp";
			 document.frm.method="post";
   			 document.frm.submit();
		}
		else
			alert("Switch not allowed");
}

function viewsip(allow,scm,act,opt){
 	   if(act=="SIP" && allow=="Y")
			{
				var tot = scm;
				document.frm.val.value =tot;
				document.frm.srch.value =opt;
 				document.frm.action="m_purchase1_sip.jsp";
				document.frm.method="post";
        document.frm.submit();
			}	else
				alert("SIP not allowed");
}

function  viewoffer(vval) {
		//alert(vval);
		var pgname = "inter_disclaimer.jsp?link="+vval;
		var features ="help=no,maximize=no,minimize=yes,scrollbars=yes,status=yes,menubars=no,toolbars=no" 
		getValue = window.showModalDialog(pgname,0,'dialogWidth:700px;dialogHeight:500px;help:no;maximize:no;minimize:yes;scrollbars:no;status=no');
        var exists = eval('getValue') ;
        if (exists)
        {
            DisplayDetails(getValue);
		 }
}

function viewsipdetails(){
			
			document.frm.action="view_sip.jsp";
			 document.frm.method="post";
   			 document.frm.submit();
}

function encryption(pwd)
{
	var len=pwd.length;
	var j=0;
	aryText = new Array(pwd.length)
	for(var i=0;i<len;i++)
	{
	   aryText[i] = pwd.charAt(i)
		
	}
	
	for(var s=0;s<aryText.length;s++)
	{
		
		if(s%2==0)
		{
			j=(aryText[s].charCodeAt(0))-5;
			
		}
		else
		{
		    j=(aryText[s].charCodeAt(0))-4;
			
		}

		
		aryText[s]=String.fromCharCode(j);
	}

	var passwd="";
	for(var s=0;s<aryText.length;s++)
	{
		passwd+=aryText[s];
		
	}
	return passwd;
}

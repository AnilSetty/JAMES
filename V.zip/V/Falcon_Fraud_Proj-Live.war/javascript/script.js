function showpop(obj,lyr,cont,conthead)
{
	var coors = findPos(obj)	
	var x = document.getElementById(lyr);
	var cont1 = cont;
	var conthead1 = conthead;
	
	x.style.display = "block";
	x.style.top = coors[1] + -10 + 'px';	
	x.style.left = coors[0] + 18 + 'px';	
	
	document.getElementById('rollcontent').innerHTML=cont1;
	document.getElementById('contheader').innerHTML=conthead1;
}
function showpop1(obj,lyr,cont,conthead)
{
	var coors = findPos(obj)	
	var x = document.getElementById(lyr);
	var cont1 = cont;
	var conthead1 = conthead;
	
	x.style.display = "block";
	x.style.top = coors[1] + -10 + 'px';	
	x.style.left = coors[0] + -317 + 'px';	
	
	document.getElementById('rollcontent').innerHTML=cont1;
	document.getElementById('contheader').innerHTML=conthead1;
}

function hidepop(obj,lyr)
{
	var x = document.getElementById(lyr);
	x.style.display = "none";
}
function findPos(obj) {
	var curleft = curtop = 0;
	if (obj.offsetParent) {
		do {
			curleft += obj.offsetLeft;
			curtop += obj.offsetTop;
		} while (obj = obj.offsetParent);
	}
	//alert(curleft)
	return [curleft,curtop];
}
function openwindow(url, width, height) { 
	
var win;
var windowName;
var params;
windowName = "features";
params = "toolbar=0,";
params += "location=0,";
params += "directories=0,";
params += "status=1,";
params += "menubar=0,";
params += "titlebar=0,";
params += "scrollbars=1,";
params += "resizable=1,";
params += "top=50,";
params += "left=50,";
params += "modal=yes,";
params += "width="+width+",";
//params += "width=120,";
params += "height="+height;
//params += ",fullscreen";

win = window.open(url, windowName, params);  
}

var widths = screen.width
var heights = screen.height
function getWidthHeight()
{
	if(widths > 800)
	{
		customheight = heights-90;		
		return customheight;					
	}
	else
	{
		customheight = 0;
		return customheight;
	}
}
function changeContent(minunit,minmunit)
{
   //alert("in changeContent" +minunit +" and "+minmunit);
	var str1 = minunit;
	var str2 = minmunit;
	if ((document.frm.radio.checked)==true)
	{
		alert(document.frm.radio.checked);
		document.frm.radio.checked=false;
		document.frm.textfield2.value="";
		document.frm.textfield2.disabled=false;
	}
   //alert(document.frm.switch1[0].checked);
	if(document.frm.switch1[0].checked== true)
	{
		 //alert("units");
		document.getElementById('span1').innerHTML="Min "+str1+" & multiples of "+str2+" thereof ";
		document.getElementById('unitid').innerHTML="<strong>Number of units:</strong>";
		document.getElementById('unitcheck').innerHTML="All Units";
	
	}
	else
	{
		 //alert("amount");
		document.getElementById('mini').value=minunit;
		//alert("1");
		document.getElementById('span1').innerHTML="Min Amount "+str1+" & in multiples of "+str2+" only ";
		//alert("2");
		document.getElementById('unitid').innerHTML="<strong>Amount:</strong>";
		//alert("3");
		document.getElementById('unitcheck').innerHTML="Entire Amount";
	}
	
}
//var path;
function tncagree()
{
alert('hi');
}

/*function tncagree(val,sch,amt,val1,actno,sesid)
{
    alert(val+""+sch+""+amt+""+val1+""+actno+""+sesid);
	var trn_mode='<%=trnmod%>';
	alert("TRNMODE:::>"+trn_mode);
	//document.frm.button.disabled=true;
	document.frm.val.value =val;
	document.frm.valpro.value =sch;
	//alert(document.frm.valpro.value);
	document.frm.textfield.value =amt;
	document.frm.st.value =val1;
	document.frm.actno.value=actno;
	//document.frm.folio.value=folioNo;
	//alert(document.frm.folio.value);
	//path=fpath;
	if(document.frm.terms.checked)
	{
	
	if(trn_mode=="T"){
		document.getElementById('button').disabled=true;
		document.frm.action="investeasy_purchaserequest_pb.jsp;jsessionid="+sesid;
	    document.frm.method="post";
		document.frm.submit();
		}
		else{
		document.getElementById('button').disabled=true;
		document.frm.action="investeasy_purchaserequest_4.jsp;jsessionid="+sesid;
	    document.frm.method="post";
		document.frm.submit();
		}
	}
	else
	{
		alert("Please agree to the terms and conditions");
	}

}*/



function activateme()
{
	document.frm.terms.disabled=false;
	
}
//// Default
function fncInputNumericValuesOnly(unit_mul)
{
     //alert(unit_mul);
     if(unit_mul == 1){
	 //alert(unit_mul);
	if(!(event.keyCode==48||event.keyCode==45||event.keyCode==48||event.keyCode==49||event.keyCode==50||event.keyCode==51||event.keyCode==52||event.keyCode==53||event.keyCode==54||event.keyCode==55||event.keyCode==56||event.keyCode==57))
	{
		event.returnValue=false;
	}
	}
	else{
	//alert('in side else');
	  if(!(event.keyCode==46||event.keyCode==48||event.keyCode==49||event.keyCode==50||event.keyCode==51||event.keyCode==52||event.keyCode==53||event.keyCode==54||event.keyCode==55||event.keyCode==56||event.keyCode==57))
	{
	event.returnValue=false;
	}
	}
}

function fncInputNumericValues()
{
if(!(event.keyCode==48||event.keyCode==49||event.keyCode==50||event.keyCode==51||event.keyCode==52||event.keyCode==53||event.keyCode==54||event.keyCode==55||event.keyCode==56||event.keyCode==57))
{
event.returnValue=false;
}
}

function funInputDecimalValues(){
	//alert("At Decimal");
	if(!(event.keyCode==46||event.keyCode==48||event.keyCode==49||event.keyCode==50||event.keyCode==51||event.keyCode==52||event.keyCode==53||event.keyCode==54||event.keyCode==55||event.keyCode==56||event.keyCode==57))
	{
	event.returnValue=false;
	}
}

function isValid(){

	var v = document.frm.textfield2.value;
	document.frm.textfield2.value = Number(document.frm.textfield2.value).toFixed(4);
}
///////////////////========================

function checkall()
{


     if (document.frm.checkboxall.checked ==true)
       {
          for(i=0;i<document.frm.checkbox.length;i++)
          {              
              document.frm.checkbox[i].checked=true
          }
       }
    if (document.frm.checkboxall.checked ==false)
      {
          for(i=0;i<document.frm.checkbox.length;i++)
            {
                document.frm.checkbox[i].checked=false
            }
     }
}



/*function tncagreeSwitch(sesid)
{
        if(document.frm.terms.checked)
        {
            document.frm.action="investeasy_redeemrequest_switch_3.jsp;jsessionid="+sesid;
            document.frm.method ="post";
        	document.frm.submit();
        }
        else
        {
                alert("Please agree to the terms and conditions");
        }
}*/

/*function termRedeem(all,sesid)
{
        if(document.frm.terms.checked)
        {
			//alert(all);
			document.frm.finval.value=all;
            document.frm.action="investeasy_redeemrequest_3.jsp;jsessionid="+sesid;
            document.frm.method ="post";
        	document.frm.submit();
        }
        else
        {
                alert("Please agree to the terms and conditions");
				return false;
        }
}*/

function activatemeredeem()
{
        document.frm.terms.disabled=false;

}

function changeContent_SWP(minunit,minmunit)
{
   //alert("in changeContent" +minunit +" and "+minmunit);
	var str1 = minunit;
	var str2 = minmunit;
	if ((document.frm.radio11.checked)==true)
	{
		alert(document.frm.radio11.checked);
		document.frm.radio11.checked=false;
		document.frm.textfield2.value="";
		document.frm.textfield2.disabled=false;
	}
   //alert(document.frm.switch1[0].checked);
	if(document.frm.switch1[0].checked== true)
	{
		 //alert("units");
		//document.getElementById('span1').innerHTML="Min "+str1+" & multiples of "+str2+" thereof ";
		document.getElementById('span1').innerHTML="Min Units "+str1;
		document.getElementById('unitid').innerHTML="<strong>Number of units:</strong>";
		//document.getElementById('unitcheck').innerHTML="All Units";
	
	}
	else
	{
		 alert("amount");
		//document.getElementById('mini').value=minunit;
		//alert("1");
		document.getElementById('span1').innerHTML="Min Amount "+str1;
		//alert("2");
		document.getElementById('unitid').innerHTML="<strong>Amount:</strong>";
		//alert("3");
		//document.getElementById('unitcheck').innerHTML="Entire Amount";
	}
	
}




$(document).ready(function(){

	$('#pending-forms').pajinate({
	  item_container_id : '.content1',	
	  start_page : 0,
	  items_per_page : 10,
	  nav_info_id: ".upload",
	  nav_label_info : "Submitted Forms",
	  nav_label_first : '<<',
	  nav_label_last : '>>',
	  nav_label_prev : '<',
	  nav_label_next : '>',
	  abort_on_small_lists : false
	});

	$('#rejected-forms').pajinate({
	  item_container_id : '.content2',
	  start_page : 0,
	  items_per_page : 10,
	  nav_info_id: ".upload",
	  nav_label_info : "Submitted Forms",
	  nav_label_first : '<<',
	  nav_label_last : '>>',
	  nav_label_prev : '<',
	  nav_label_next : '>',
	  abort_on_small_lists : false
	});
	
	$('#approved-forms').pajinate({
	  item_container_id : '.content3',
	  start_page : 0,
	  items_per_page : 10,
	  nav_info_id: ".upload",
	  nav_label_info : "Submitted Forms",
	  nav_label_first : '<<',
	  nav_label_last : '>>',
	  nav_label_prev : '<',
	  nav_label_next : '>',
	  abort_on_small_lists : false
	});
	
	$('#draft-forms').pajinate({
		  item_container_id : '.content4',
		  start_page : 0,
		  items_per_page : 10,
		  nav_info_id: ".upload",
		  nav_label_info : "Drafts",
		  nav_label_first : '<<',
		  nav_label_last : '>>',
		  nav_label_prev : '<',
		  nav_label_next : '>',
		  abort_on_small_lists : false
		});
	$('#deregister-forms').pajinate({
		  item_container_id : '.content4',
		  start_page : 0,
		  items_per_page : 10,
		  nav_info_id: ".upload",
		  nav_label_info : "Drafts",
		  nav_label_first : '<<',
		  nav_label_last : '>>',
		  nav_label_prev : '<',
		  nav_label_next : '>',
		  abort_on_small_lists : false
		});
});       
